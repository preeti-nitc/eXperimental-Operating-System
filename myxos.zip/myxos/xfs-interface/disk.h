#define DISK_NAME 	"disk.xfs"
#define BOOT_BLOCK	0
